import { FaBars } from "react-icons/fa";

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  toggleSidebar: () => void;
}

const Header = ({ currentPage, setCurrentPage, toggleSidebar }: HeaderProps) => {
  return (
    <header className="flex justify-between items-center p-3 bg-gray-100">
      <div className="flex items-center">
        <button onClick={toggleSidebar} className="text-xl mr-2">
          <FaBars />
        </button>
        <span
          className="cursor-pointer"
          onClick={() => setCurrentPage("Home")}
        >
          <img 
            src="/../public/assets/images/xenoptics-logo.ico" 
            alt="XenOptics Intranet" 
            className="w-8 h-8" 
          />
        </span>
        <span className="text-xl font-semibold ml-2 truncate"> 
          {/* text-base => to a little smaller */}
          {currentPage}
        </span>
      </div>
    </header>
  );
};

export default Header;