export interface SystemCardData {
    id: number;
    title: string;
    image: string;
    description: string;
    status: boolean; 
    weblink: string; 
}

export const systemData: SystemCardData[] = [
    {
        id: 1,
        title: "OT Request System",
        image: "/../public/assets/images/ot-logo.png",
        description: "Manage overtime requests efficiently.",
        status: true, 
        weblink: 'https://apps.powerapps.com/play/e/default-b8c84464-86e7-4d3a-8c4d-d5b1acce5b88/a/1906d0ad-8055-492a-aa78-380fbc744ed5?tenantId=b8c84464-86e7-4d3a-8c4d-d5b1acce5b88&hint=92f7fb96-5cea-41cf-8aa1-005c007dbda7&sourcetime=1721810145590', 
    }, 
    {
        id: 2,
        title: "Outside Request & Reimbursement System",
        image: "/../public/assets/images/orr-logo.png",
        description: "Handle external requests and reimbursements.",
        status: true, 
        weblink: 'https://apps.powerapps.com/play/e/default-b8c84464-86e7-4d3a-8c4d-d5b1acce5b88/a/cc1256b2-4747-4211-bbd0-a54e1429837c?tenantId=b8c84464-86e7-4d3a-8c4d-d5b1acce5b88&hint=3b21798a-22d2-41a4-96e9-6f483572580a&sourcetime=1721808705539', 
    },
    {
        id: 3,
        title: "RapidStart CRM",
        image: "/../public/assets/images/rs-crm-logo.png",
        description: "Track and manage maintenance tasks.",
        status: true, 
        weblink: "https://xenoptics.crm6.dynamics.com/main.aspx?appid=7e22bc49-af94-ee11-be37-000d3aca6cb5", 
    },
    {
        id: 4,
        title: "Document Control System",
        image: "/../public/assets/images/docu-control-logo.png",
        description: "Manage overtime requests efficiently.",
        status: true, 
        weblink: "https://xenoptics.crm6.dynamics.com/main.aspx?appid=7e22bc49-af94-ee11-be37-000d3aca6cb5", 
    },
    {
        id: 5,
        title: "Maintenance System",
        image: "/../public/assets/images/maintenance-logo.png",
        description: "Handle external requests and reimbursements.",
        status: true, 
        weblink: "https://xenons.sharepoint.com/SitePages/HR-Training-Forms-Link.aspx", 
    },
    {
        id: 6,
        title: "Sample System Two",
        image: "/../public/assets/images/maintenance-logo.png",
        description: "Track and manage maintenance tasks.",
        status: true, 
        weblink: "https://forms.office.com/pages/responsepage.aspx?id=ZETIuOeGOk2MTdWxrM5biO-DvagkD4tPqliccLY3HWVUNjhUUUdRV0IwUTJINzI5UkZOVEUwMjZIWSQlQCN0PWcu", 
    },
    {
        id: 7,
        title: "HR Training Forms", 
        image: "/../public/assets/images/maintenance-logo.png",
        description: "Track and manage maintenance tasks.",
        status: true, 
        weblink: "https://forms.office.com/pages/responsepage.aspx?id=ZETIuOeGOk2MTdWxrM5biO-DvagkD4tPqliccLY3HWVUNjhUUUdRV0IwUTJINzI5UkZOVEUwMjZIWSQlQCN0PWcu", 
    },
];
